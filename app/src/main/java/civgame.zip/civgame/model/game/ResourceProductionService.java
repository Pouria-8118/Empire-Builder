package civgame.model.game;

import civgame.model.building.Building;
import civgame.model.building.Dock;
import civgame.model.map.HexTile;
import civgame.model.resource.ResourceType;
import civgame.util.Constants;

import java.util.ArrayList;
import java.util.List;

public class ResourceProductionService {

    public List<String> applyProduction(GameSession gameSession) {
        List<String> depletedDescriptions = applyBuildingProduction(gameSession);
        applyFarmSynergyBonus(gameSession);
        applyTownHallSafeguardProduction(gameSession);
        return depletedDescriptions;
    }

    private List<String> applyBuildingProduction(GameSession gameSession) {
        List<String> depletedDescriptions = new ArrayList<String>();
        List<Building> allBuildings = gameSession.getAllBuildings();

        for (int i = 0; i < allBuildings.size(); i++) {
            Building building = allBuildings.get(i);
            if (building.isDestroyed()) {
                continue;
            }

            HexTile resourceTile = resolveResourceTile(gameSession, building);
            if (resourceTile == null || !resourceTile.hasResource()) {
                continue;
            }

            double multiplier = gameSession.getTownHallUpgradeService().getProductionMultiplier(building.getBuildingType());
            int producedAmount = (int) (building.calculateProduction() * multiplier);

            if (producedAmount <= 0) {
                continue;
            }

            int adjacencyBonus = gameSession.getAdjacencyBonusService().getBuildingBonus(building);
            int totalProducedAmount = producedAmount + adjacencyBonus;

            gameSession.getResourceStorage().addResource(building.getResourceProduced(), totalProducedAmount);
            resourceTile.consumeResourceCapacity(producedAmount);

            if (!resourceTile.hasResource()) {
                building.clearAllStationedWorkers();
                depletedDescriptions.add(building.getBuildingType().name() + " ran out of resources");
            }
        }

        return depletedDescriptions;
    }

    private HexTile resolveResourceTile(GameSession gameSession, Building building) {
        if (building instanceof Dock) {
            return DockResourceFinder.findAdjacentFishTile(gameSession, building.getCoordinate());
        }
        return gameSession.getHexMap().getTile(building.getCoordinate());
    }

    private void applyFarmSynergyBonus(GameSession gameSession) {
        int bonus = gameSession.getAdjacencyBonusService().getFarmSynergyBonus();
        if (bonus > 0) {
            gameSession.getResourceStorage().addResource(ResourceType.FOOD, bonus);
        }
    }

    private void applyTownHallSafeguardProduction(GameSession gameSession) {
        gameSession.getResourceStorage().addResource(ResourceType.FOOD, Constants.TOWN_HALL_SAFEGUARD_FOOD);
        gameSession.getResourceStorage().addResource(ResourceType.WOOD, Constants.TOWN_HALL_SAFEGUARD_WOOD);
    }
}